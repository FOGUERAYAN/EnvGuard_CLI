# 🛡️ envguard
A zero-dependency CLI tool to validate your .env files against a declarative schema.

## Install
```bash
npm install -g envguard
Usage ExamplesInitialize: envguard initValidate: envguard validate --schema my.schema.json --env .envCompare: envguard diff .env .env.exampleSchema ReferencePropertyTypeDescriptiontypestringstring, number, boolean, url, enumrequiredbooleanIf true, fails if variable is missingdefaultanyValue used if variable is missingExit CodesCodeMeaning0Success1Validation Failure2Config/Schema Error3IO / System Error
---
